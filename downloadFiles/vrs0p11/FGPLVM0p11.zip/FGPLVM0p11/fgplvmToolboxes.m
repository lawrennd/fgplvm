% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
%
% 

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmToolboxes.m version 1.1


importLatest('kern');
importLatest('prior');
importLatest('optimi');
importLatest('mltools');
importLatest('datasets');
importLatest('ndlutil');
