function ll = fgplvmDynamicsLogLikelihood(model)

% FGPLVMDYNAMICSLOGLIKELIHOOD Gradients of the dynamics portion of the log likelihood..
%
% ll = fgplvmDynamicsLogLikelihood(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmDynamicsLogLikelihood.m version 1.1



if ~isfield(model, 'dynamics')
  error('This model does not contain dynamics');
end
model.dynamics.Y = model.X(2:end, :);
ll = ll + fgplvmLogLikelihood(model.dynamics);
  