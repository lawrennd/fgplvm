% FGPLVM toolbox
% Version 0.11		Tuesday 27 Dec 2005 at 18:17
% Copyright (c) 2005 Neil D. Lawrence
% 
% DEMOIL1 Oil data with fully independent training conditional.
% DEMOIL2 Oil data with fully independent training conditional, and MLP back constraints.
% DEMOIL3 Oil data with deterministic training conditional approximation.
% DEMOIL5 Oil data with deterministic training conditional, and MLP back constraints.
% DEMOIL5 Oil data with partially independent training conditional, and MLP back constraints.
% DEMOIL6 Oil data with partially independent training conditional, and MLP back constraints.
% DEMROBOTWIRELESS1 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMROBOTWIRELESS2 Wireless Robot data from University of Washington, with back constraints and dynamics.
% DEMROBOTWIRELESS3 Wireless Robot data from University of Washington with dynamics, but no back constraints.
% DEMROBOTWIRELESS4 Wireless Robot data from University of Washington with back constraints but no dynamics.
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D2 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSTICK1 Model the stick man using an RBF kernel.
% DEMSTICK2 Model the stick man using an RBF kernel and dynamics.
% DEMVOWELS1 Model the vowels data with a 2-D FGPLVM using RBF kernel.
% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
% FGPLVMCLASSVISUALISE Callback function for visualising data in 2-D.
% FGPLVMCOVGRADSTEST Test the gradients of the covariance.
% FGPLVMCREATE Create a GPLVM model with inducing varibles.
% FGPLVMDYNAMICSFIELDPLOT 2-D field plot of the dynamics.
% FGPLVMDYNAMICSLOGLIKEGRADIENTS Gradients of the dynamics portion.
% FGPLVMDYNAMICSPLOT 2-D scatter plot of the latent points.
% FGPLVMDYNAMICSPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMDYNAMICSRUN Visualise the manifold.
% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
% FGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% FGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% FGPLVMFIELDPLOT 2-D field plot of the dynamics.
% FGPLVMGRADIENT GP-LVM gradient wrapper.
% FGPLVMKERNDYNAMICSSAMPLE Sample a field from a given kernel.
% FGPLVMLOADRESULT Load a previously saved result.
% FGPLVMLOGLIKEGRADIENTS Compute the gradients of the EZFT sparse covariance.
% FGPLVMLOGLIKELIHOOD Log-likelihood for a GP-LVM.
% FGPLVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% FGPLVMOBJECTIVE Wrapper function for GPLVM objective.
% FGPLVMOPTIMISE Optimise the inducing variable based kernel.
% FGPLVMOPTIMISEPOINT Optimise the postion of a point.
% FGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% FGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% FGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% FGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point.
% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMREADFROMFID Load from a FID produced by the C++ implementation.
% FGPLVMREADFROMFILE Load a file produced by the c++ implementation.
% FGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% FGPLVMTEST Test the gradients of the gpCovGrads function and the fgplvm models.
% FGPLVMVISUALISE Visualise the manifold.
% GPCOMPUTEALPHA Update the vector `alpha' for computing posterior mean quickly.
% GPCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% GPCOVGRADSTEST Test the gradients of the covariance.
% GPCREATE Create a GP model with inducing varibles/pseudo-inputs.
% GPEXPANDPARAMS Expand a parameter vector into a GP model.
% GPEXTRACTPARAM Extract a parameter vector from a GP model.
% GPGRADIENT Gradient wrapper for a GP model.
% GPLOGLIKEGRADIENTS Compute the gradients for the parameters and X.
% GPLOGLIKELIHOOD Compute the log likelihood of a GP.
% GPOBJECTIVE Wrapper function for GP objective.
% GPOPTIMISE Optimise the inducing variable based kernel.
% GPPOSTERIORGRADMEANVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPUPDATEKERNELS Update the kernels that are needed.
