function param = robOneDynamicsExtractParam(model)

% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.
%
%	Description:
%	param = robOneDynamicsExtractParam(model)
%% 	robOneDynamicsExtractParam.m CVS version 1.3
% 	robOneDynamicsExtractParam.m SVN version 29
% 	last update 2007-11-03T14:33:41.000000Z

param = [];