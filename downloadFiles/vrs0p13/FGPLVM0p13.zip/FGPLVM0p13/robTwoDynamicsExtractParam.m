function param = robTwoDynamicsExtractParam(model)

% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.
%
% param = robTwoDynamicsExtractParam(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% robTwoDynamicsExtractParam.m version 1.1



param = [];