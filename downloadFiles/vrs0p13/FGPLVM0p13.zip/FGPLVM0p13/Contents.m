% FGPLVM toolbox
% Version 0.13		Friday 20 Jan 2006 at 18:41
% Copyright (c) 2006 Neil D. Lawrence
% 
% DEMOIL1 Oil data with fully independent training conditional.
% FGPLVMKERNDYNAMICSSAMPLE Sample a field from a given kernel.
% FGPLVMTEST Test the gradients of the gpCovGrads function and the fgplvm models.
% FGPLVMCLASSVISUALISE Callback function for visualising data in 2-D.
% FGPLVMCREATE Create a GPLVM model with inducing varibles.
% FGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% FGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% FGPLVMGRADIENT GP-LVM gradient wrapper.
% FGPLVMLOADRESULT Load a previously saved result.
% FGPLVMLOGLIKEGRADIENTS Compute the gradients of the EZFT sparse covariance.
% FGPLVMLOGLIKELIHOOD Log-likelihood for a GP-LVM.
% FGPLVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% FGPLVMOBJECTIVE Wrapper function for GPLVM objective.
% FGPLVMOPTIMISE Optimise the inducing variable based kernel.
% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMREADFROMFID Load from a FID produced by the C++ implementation.
% FGPLVMREADFROMFILE Load a file produced by the c++ implementation.
% FGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% FGPLVMVISUALISE Visualise the manifold.
% DEMSTICK2 Model the stick man using an RBF kernel and dynamics.
% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
% FGPLVMDYNAMICSFIELDPLOT 2-D field plot of the dynamics.
% DEMROBOTWIRELESSNAVIGATE Take some test data for the robot and navigate with it.
% FGPLVMDYNAMICSPLOT 2-D scatter plot of the latent points.
% DEMSTICK1 Model the stick man using an RBF kernel.
% FGPLVMDYNAMICSRUN Visualise the manifold.
% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
% FGPLVMFIELDPLOT 2-D field plot of the dynamics.
% DEMROBOTWIRELESS4 Wireless Robot data from University of Washington with dynamics and no back constraints.
% DEMOIL2 Oil data with fully independent training conditional, and MLP back constraints.
% DEMVOWELS1 Model the vowels data with a 2-D FGPLVM using RBF kernel.
% DEMSPGP1D4 Do a simple 1-D regression after Snelson & Ghahramani's example.
% FGPLVMCOVGRADSTEST Test the gradients of the covariance.
% DEMOIL3 Oil data with deterministic training conditional.
% DEMOIL4 Oil data with deterministic training conditional, and MLP back constraints.
% DEMOIL5 Oil data with partially independent training conditional.
% GPOUT Evaluate the output of an Gaussian process model.
% GPSCALEBIASGRADIENT Compute the gradient of the scale and bias.
% GPOPTIONS Return default options for FGPLVM model.
% DEMROBOTWIRELESS2 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMROBOTWIRELESS4 Wireless Robot data from University of Washington with dynamics and back constraints.
% DEMROBOTWIRELESS1 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% FGPLVMDYNAMICSPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMOPTIMISEPOINT Optimise the postion of a point.
% FGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% FGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% FGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% FGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point.
% DEMOIL6 Oil data with partially independent training conditional, and MLP back constraints.
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D2 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D3 Do a simple 1-D regression after Snelson & Ghahramani's example.
% GPDYNAMICSDISPLAY Display a GP dynamics model.
% GPPOSTERIORMEANCOVAR Mean and covariances of the posterior at points given by X.
% GPCOMPUTEALPHA Update the vector `alpha' for computing posterior mean quickly.
% GPCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% GPCOVGRADSTEST Test the gradients of the covariance.
% GPCREATE Create a GP model with inducing varibles/pseudo-inputs.
% GPEXPANDPARAM Expand a parameter vector into a GP model.
% GPGRADIENT Gradient wrapper for a GP model.
% GPLOGLIKEGRADIENTS Compute the gradients for the parameters and X.
% GPLOGLIKELIHOOD Compute the log likelihood of a GP.
% GPOBJECTIVE Wrapper function for GP objective.
% GPOPTIMISE Optimise the inducing variable based kernel.
% GPPOSTERIORGRADMEANVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPUPDATEKERNELS Update the kernels that are needed.
% GPDYNAMICSSAMP Sample from the dynamics for a given input.
% GPCOMPUTEM Compute the matrix m given the model.
% GPEXTRACTPARAM Extract a parameter vector from a GP model.
% GPDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% GPDYNAMICSEXTRACTPARAM Extract parameters from the GP dynamics model.
% GPDYNAMICSCREATE Create the dynamics model. 
% DEMWALKSITJOG1 Model the stick man using an RBF kernel.
% DEMROBOTWIRELESSNAVIGATE Take some test data for the robot and navigate with it.
% GPDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% GPDYNAMICSLOGLIKEGRADIENTS Gradients of the GP dynamics wrt parameters.
% GPDYNAMICSLOGLIKELIHOOD Give the log likelihood of the dynamics part.
% GPDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% MODELLATENTGRADIENTS Gradients of the latent variables for dynamics models in the GPLVM.
% MODELSETLATENTVALUES Set the latent variables for dynamics models in the GPLVM.
% ROBONEDYNAMICSCREATE Create the dynamics model. 
% ROBONEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.
% ROBONEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.
% ROBONEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% ROBONEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% ROBTWODYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% ROBTWODYNAMICSCREATE Create the dynamics model. 
% ROBTWODYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.
% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.
% ROBTWODYNAMICSSETLATENTVALUES Set the latent values inside the model.
% ROBTWODYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% DEMWALKSITJOG2 Model the stick man using an RBF kernel.
% DYNAMICSTEST Run some tests on the specified dynamics model.
% CMDSROADDATA This script uses classical MDS to visualise some road distance data.
% DEMSTICK3 Model the stick man using an RBF kernel and mlp back constraints.
% FGPLVMOPTIONS Return default options for FGPLVM model.
% FGPLVMDISPLAY Display an FGPLVM model.
% GPDISPLAY Display a Gaussian process model.
% ROBONEDYNAMICSDISPLAY Display the robot dynamics model. 
% ROBTWODYNAMICSDISPLAY Display the robot dynamics model. 
% DEMSTICK4 Model the stick man using an RBF kernel and 3-D latent space.
% DEMVOWELS2 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints.
% FGPLVMPRINTPLOT Print latent space for learnt model.
% DEMSPGP1DPLOT Plot results from 1-D sparse GP.
% DEMVOWELS3 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints, but without PCA initialisation.
