function options = fgplvmOptions(varargin);

% FGPLVMOPTIONS Return default options for FGPLVM model.
%
% options = fgplvmOptions(varargin);
%

% Copyright (c) 2006 Neil D. Lawrence
% fgplvmOptions.m version 1.1



options = gpOptions(varargin{:});

options.initX = 'ppca';
options.prior = 'gaussian';
options.back = [];
options.backOptions = [];
options.optimiseInitBack = 1;
options.inducingPrior = 'gaussian';
