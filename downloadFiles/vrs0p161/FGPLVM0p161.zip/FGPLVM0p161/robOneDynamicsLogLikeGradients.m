function g = robOneDynamicsLogLikeGradients(model)

% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.
%
%	Description:
%	g = robOneDynamicsLogLikeGradients(model)
%% 	robOneDynamicsLogLikeGradients.m CVS version 1.3
% 	robOneDynamicsLogLikeGradients.m SVN version 29
% 	last update 2007-11-03T14:33:41.000000Z

g = [];