function g = modelLatentGradients(model)

% MODELLATENTGRADIENTS Gradients of the latent variables for dynamics models in the GPLVM.
%
%	Description:
%	g = modelLatentGradients(model)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	modelLatentGradients.m version 1.3


fhandle = str2func([model.type 'LatentGradients']);
g = fhandle(model);