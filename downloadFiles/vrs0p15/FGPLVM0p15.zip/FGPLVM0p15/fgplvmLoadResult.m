function [model, lbls] = fgplvmLoadResult(dataSet, number)

% FGPLVMLOADRESULT Load a previously saved result.
%
%	Description:
%	[model, lbls] = fgplvmLoadResult(dataSet, number)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	fgplvmLoadResult.m version 1.3


[Y, lbls] = lvmLoadData(dataSet);

dataSet(1) = upper(dataSet(1));
load(['dem' dataSet num2str(number)])
