function ll = fgplvmLogLikelihood(model)

% FGPLVMLOGLIKELIHOOD Log-likelihood for a GP-LVM.
%
%	Description:
%
%	LL = FGPLVMLOGLIKELIHOOD(MODEL) returns the log likelihood for a
%	given GP-LVM model.
%	 Returns:
%	  LL - the log likelihood of the data given the model.
%	 Arguments:
%	  MODEL - the model for which the log likelihood is to be computed.
%	   The model contains the data for which the likelihood is being
%	   computed in the 'y' component of the structure.
%	
%
%	See also
%	GPLOGLIKELIHOOD, FGPLVMCREATE


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	fgplvmLogLikelihood.m version 1.4



ll = gpLogLikelihood(model);

if isfield(model, 'dynamics') & ~isempty(model.dynamics)
  % A dynamics model is being used.
  ll = ll + modelLogLikelihood(model.dynamics);
elseif isfield(model, 'prior') &  ~isempty(model.prior)
  for i = 1:model.N
    ll = ll + priorLogProb(model.prior, model.X(i, :));
  end
end

switch model.approx
  case {'dtc', 'fitc', 'pitc'}
   if isfield(model, 'inducingPrior') &  ~isempty(model.inducingPrior)
     for i = 1:model.k
       ll = ll + priorLogProb(model.inducingPrior, model.X_u(i, :));    
     end
   end
 otherwise
  % do nothing
end


