function model = gpReversibleDynamicsExpandParam(model, params)

% GPREVERSIBLEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
%
%	Description:
%	model = gpReversibleDynamicsExpandParam(model, params)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	gpReversibleDynamicsExpandParam.m version 1.3


model = gpDynamicsExpandParam(model, params);
