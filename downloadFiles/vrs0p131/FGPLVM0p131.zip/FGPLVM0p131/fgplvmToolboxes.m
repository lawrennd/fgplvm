% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
%
% 

% Copyright (c) 2006 Neil D. Lawrence
% fgplvmToolboxes.m version 1.3


importLatest('prior');
importLatest('optimi');
importLatest('mocap')
importLatest('ndlutil');
importLatest('kern');
importLatest('datasets');
importLatest('mltools');