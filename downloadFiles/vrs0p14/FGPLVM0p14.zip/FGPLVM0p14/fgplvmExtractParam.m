function params = fgplvmExtractParam(model)

% FGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
%
%	Description:
%
%	PARAMS = FGPLVMEXTRACTPARAM(MODEL) extracts a parameter vector from
%	a given FGPLVM structure.
%	 Returns:
%	  PARAMS - the parameter vector extracted from the model.
%	 Arguments:
%	  MODEL - the model from which parameters are to be extracted.
%	
%
%	See also
%	FGPLVMCREATE, FGPLVMEXPANDPARAM, MODELEXTRACTPARAM


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	fgplvmExtractParam.m version 1.4


params = gpExtractParam(model);
if isfield(model, 'back')
  params = [modelExtractParam(model.back) params];
else
  params = [model.X(:)' params];
end
if isfield(model, 'dynamics') 
  params = [params modelExtractParam(model.dynamics)];
end