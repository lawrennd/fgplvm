function param = robTwoDynamicsExtractParam(model)

% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.
%
%	Description:
%	param = robTwoDynamicsExtractParam(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	robTwoDynamicsExtractParam.m version 1.3


param = [];