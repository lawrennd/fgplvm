function g = robThreeDynamicsLogLikeGradients(model)

% ROBTHREEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot three dynamics wrt parameters.
%
%	Description:
%	g = robThreeDynamicsLogLikeGradients(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	robThreeDynamicsLogLikeGradients.m version 1.2


g = [];