function model = robThreeSetLatentValues(model, X)
