function [mu, varsigma] = fgplvmPosteriorMeanVar(model, X);

% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
%
%	Description:
%	[mu, varsigma] = fgplvmPosteriorMeanVar(model, X);
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	fgplvmPosteriorMeanVar.m version 1.3


[mu, varsigma] = gpPosteriorMeanVar(model, X);