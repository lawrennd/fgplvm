function gpReversibleDynamicsDisplay(model, varargin)

% GPREVERSIBLEDYNAMICSDISPLAY Display a GP dynamics model.
%
%	Description:
%	gpReversibleDynamicsDisplay(model, varargin)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	gpReversibleDynamicsDisplay.m version 1.3


gpDisplay(model, varargin{:});