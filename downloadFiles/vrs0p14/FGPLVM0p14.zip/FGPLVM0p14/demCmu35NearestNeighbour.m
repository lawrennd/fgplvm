
% DEMCMU35NEARESTNEIGHBOUR Recreate the Nearest Neighbour result from Taylor et al.
%
%	Description:
%	

%	Copyright (c) 2006 Neil D. Lawrence
% 	demCmu35NearestNeighbour.m version 



datasetName = 'cmu35Taylor';
[Y, lbls, Ytest, lblsTest] = lvmLoadData(datasetName);
bias = mean(Y);
scale = 1./sqrt(var(Y));
%scale = ones(size(scale));
Y = Y - repmat(bias, size(Y, 1), 1);
Ytest = Ytest - repmat(bias, size(Ytest, 1), 1);
Y = Y.*repmat(scale, size(Y, 1), 1);
Ytest = Ytest.*repmat(scale, size(Ytest, 1), 1);

% Indices associated with right leg.
legInd = [8:14];
leglessInd = [1:7 15:57 65:100 101:size(Y, 2)];
YtrainLeg = Y(:, leglessInd);
startInd = 44+62;
YtestLeg = Ytest(startInd:end, leglessInd);

dists = dist2(YtrainLeg, YtestLeg);
[void, bestIndLeg] = min(dists);
lenVal = size(Ytest, 1) - startInd + 1;
errLeg = (Ytest(startInd:end, legInd)-Y(bestIndLeg, legInd))./repmat(scale(legInd), lenVal, 1);
%Ypred = Ytest(startInd:end, :);
%Ypred(:, legInd) = Y(bestIndLeg, legInd);
%errLeg = (Ytest(startInd:end, :) - Ypred)./repmat(scale, lenVal, 1);
errLeg = errLeg*180/pi;
errLeg = mean(mean((errLeg.*errLeg)));

figure(1)
clf
subplot(1, 2, 1);
plot(1:size(Ytest, 1), Ytest(:, 8), '-')
hold on
plot(1:size(Ytest, 1), [Ytest(1:startInd-1, 8); Y(bestIndLeg, 8)], '--')
subplot(1, 2, 2);
plot(1:size(Ytest, 1), Ytest(:, 9), '-')
hold on
plot(1:size(Ytest, 1), [Ytest(1:startInd-1, 9); Y(bestIndLeg, 9)], '--')

% Indices associated with upper body.
bodyInd = [24:50];
bodylessInd = [1:23 51:size(Y, 2)];
YtrainBody = Y(:, bodylessInd);
YtestBody = Ytest(startInd:end, bodylessInd);

dists = dist2(YtrainBody, YtestBody);
[void, bestIndBody] = min(dists);
lenVal = size(Ytest, 1) - startInd + 1;
errBody = (Ytest(startInd:end, bodyInd)-Y(bestIndBody, bodyInd))./repmat(scale(bodyInd), ...
                                                  lenVal, 1);
errBody = errBody*180/pi;
errBody = mean(mean((errBody.*errBody)));

