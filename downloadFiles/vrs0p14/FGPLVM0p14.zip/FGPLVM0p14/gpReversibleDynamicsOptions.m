function options = gpReversibleDynamicsOptions(approx);
