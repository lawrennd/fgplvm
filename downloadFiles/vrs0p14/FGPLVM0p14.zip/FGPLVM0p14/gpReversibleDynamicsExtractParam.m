function param = gpReversibleDynamicsExtractParam(model)

% GPREVERSIBLEDYNAMICSEXTRACTPARAM Extract parameters from the GP reversible dynamics model.
%
%	Description:
%	param = gpReversibleDynamicsExtractParam(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	gpReversibleDynamicsExtractParam.m version 1.3


param = gpDynamicsExtractParam(model);
