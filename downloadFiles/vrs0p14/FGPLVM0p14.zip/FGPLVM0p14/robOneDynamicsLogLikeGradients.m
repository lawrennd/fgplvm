function g = robOneDynamicsLogLikeGradients(model)

% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.
%
%	Description:
%	g = robOneDynamicsLogLikeGradients(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	robOneDynamicsLogLikeGradients.m version 1.3


g = [];