function params = gpExtractParam(model)

% GPEXTRACTPARAM Extract a parameter vector from a GP model.
%
%	Description:
%
%	PARAMS = GPEXTRACTPARAM(MODEL) extracts the model parameters from a
%	structure containing the information about a Gaussian process.
%	 Returns:
%	  PARAMS - a vector of parameters from the model.
%	 Arguments:
%	  MODEL - the model structure containing the information about the
%	   model.
%	
%
%	See also
%	GPCREATE, GPEXPANDPARAM, MODELEXTRACTPARAM


%	Copyright (c) 2005, 2006 Neil D. Lawrence
% 	gpExtractParam.m version 1.5


if model.learnScales
  fhandle = str2func([model.scaleTransform 'Transform']);
  scaleParams = fhandle(model.scale, 'xtoa');
else
  scaleParams = [];
end
switch model.approx
 case 'ftc'
  params =  [kernExtractParam(model.kern) scaleParams];
 case {'dtc', 'fitc', 'pitc'}
  fhandle = str2func([model.betaTransform 'Transform']);
  paramPart = [kernExtractParam(model.kern) ...
               scaleParams fhandle(model.beta, 'xtoa')];
  if model.fixInducing
    params = paramPart;
  else
    params =  [model.X_u(:)' paramPart];
  end
end

