
% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
%
%	Description:
%	

%	Copyright (c) 2007 Neil D. Lawrence
% 	fgplvmToolboxes.m version 1.12

importLatest('netlab');
importLatest('prior');
importLatest('optimi');
importLatest('datasets');
importLatest('mltools');
importLatest('kern');
importLatest('ndlutil');
importLatest('mocap');
importLatest('gp');