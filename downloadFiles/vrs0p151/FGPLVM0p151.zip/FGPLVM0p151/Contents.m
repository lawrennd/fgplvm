% FGPLVM toolbox
% Version 0.151		14-Feb-2007
% Copyright (c) 2007 Neil D. Lawrence
% 
% CMDSROADDATA This script uses classical MDS to visualise some road distance data.
% DEMBRENDAN1 Use the GP-LVM to model the Frey face data with back constraints.
% DEMCMU35GPLVM1 Learn a GPLVM on CMU 35 data set.
% DEMCMU35GPLVM2 Learn a GPLVM on CMU 35 data set.
% DEMCMU35GPLVM3 Learn a GPLVM on CMU 35 data set.
% DEMCMU35GPLVMRECONSTRUCT Reconstruct right leg and body of CMU 35.
% DEMCMU35GPLVMRECONSTRUCTTAYLOR Reconstruct right leg of CMU 35.
% DEMCMU35TAYLORNEARESTNEIGHBOUR Recreate the Nearest Neighbour result from Taylor et al, NIPS 2006.
% DEMFOURWALKS1 Model four seperate walsk using an RBF kernel and dynamics.
% DEMFOURWALKSRECONSTRUCT Reconstruct right leg of CMU 35.
% DEMOIL1 Oil data with fully independent training conditional.
% DEMOIL2 Oil data with fully independent training conditional, and MLP back constraints.
% DEMOIL3 Oil data with deterministic training conditional.
% DEMOIL4 Oil data with deterministic training conditional, and MLP back constraints.
% DEMOIL5 Oil data with partially independent training conditional.
% DEMOIL6 Oil data with partially independent training conditional, and MLP back constraints.
% DEMROBOTTRACES1 Wireless Robot data from University of Washington, with tailored dynamics.
% DEMROBOTWIRELESS1 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMROBOTWIRELESS2 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMROBOTWIRELESS3 Wireless Robot data from University of Washington with dynamics and no back constraints.
% DEMROBOTWIRELESS4 Wireless Robot data from University of Washington with dynamics and back constraints.
% DEMROBOTWIRELESSNAVIGATE Take some test data for the robot and navigate with it.
% DEMSTICK1 Model the stick man using an RBF kernel.
% DEMSTICK2 Model the stick man using an RBF kernel and dynamics.
% DEMSTICK3 Model the stick man using an RBF kernel and RBF kernel based back constraints.
% DEMSTICK4 Model the stick man using an RBF kernel and 3-D latent space.
% DEMSTICK5 Model the stick man using an RBF kernel and regressive dynamics.
% DEMTWOCLUSTERS1
% DEMVOWELS1 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints.
% DEMVOWELS2 Model the vowels data with a 2-D FGPLVM using RBF kernel.
% DEMVOWELS3 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints, but without PCA initialisation.
% DEMVOWELSISOMAP Model the vowels data with a 2-D FGPLVM using RBF kernel.
% DEMVOWELSLLE Model the vowels data with a 2-D FGPLVM using RBF kernel.
% DEMWALKSITJOGDYNAMICSLEARN Learn the stick man dynamics.
% DYNAMICSTEST Run some tests on the specified dynamics model.
% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
% FGPLVMBACKCONSTRAINTGRAD Gradient with respect to back constraints if present.
% FGPLVMCLASSVISUALISE Callback function for visualising data in 2-D.
% FGPLVMCOVGRADSTEST Test the gradients of the covariance.
% FGPLVMCREATE Create a GPLVM model with inducing variables.
% FGPLVMDISPLAY Display an FGPLVM model.
% FGPLVMDYNAMICSFIELDPLOT 2-D field plot of the dynamics.
% FGPLVMDYNAMICSPLOT 2-D scatter plot of the latent points.
% FGPLVMDYNAMICSPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMDYNAMICSRUN Runs auto regressive dynamics in a forward manner.
% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
% FGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% FGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% FGPLVMFIELDPLOT 2-D field plot of the dynamics.
% FGPLVMGRADIENT GP-LVM gradient wrapper.
% FGPLVMKERNDYNAMICSSAMPLE Sample a field from a given kernel.
% FGPLVMLOADRESULT Load a previously saved result.
% FGPLVMLOGLIKEGRADIENTS Compute the gradients for the FGPLVM.
% FGPLVMLOGLIKELIHOOD Log-likelihood for a GP-LVM.
% FGPLVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% FGPLVMOBJECTIVE Wrapper function for GP-LVM objective.
% FGPLVMOBJECTIVEGRADIENT Wrapper function for FGPLVM objective and gradient.
% FGPLVMOPTIMISE Optimise the FGPLVM.
% FGPLVMOPTIMISEPOINT Optimise the postion of a latent point.
% FGPLVMOPTIMISESEQUENCE Optimise the postion of a latent sequence.
% FGPLVMOPTIONS Return default options for FGPLVM model.
% FGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% FGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% FGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% FGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% FGPLVMPOINTOBJECTIVEGRADIENT Wrapper function for objective and gradient of a single point in latent space and the output location..
% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMPRINTPLOT Print latent space for learnt model.
% FGPLVMREADFROMFID Load from a FID produced by the C++ implementation.
% FGPLVMREADFROMFILE Load a file produced by the C++ implementation.
% FGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% FGPLVMSEQUENCEGRADIENT Wrapper function for gradient of a latent sequence.
% FGPLVMSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM.
% FGPLVMSEQUENCELOGLIKELIHOOD Log-likelihood of a sequence for the GP-LVM.
% FGPLVMSEQUENCEOBJECTIVE Wrapper function for objective of a single sequence in latent space and the corresponding output sequence.
% FGPLVMSEQUENCEOBJECTIVEGRADIENT Wrapper function for objective
% FGPLVMTAYLORANGLEERRORS Helper function for computing angle errors for CMU 35 data.
% FGPLVMTEST Test the gradients of the gpCovGrads function and the fgplvm models.
% FGPLVMTESTMISSING Make sure missing data likelihood match full ones.
% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
% FGPLVMVISUALISE Visualise the manifold.
% FGPLVMVITERBISEQUENCE Viterbi align a latent sequence.
% GPDYNAMICSCREATE Create the dynamics model. 
% GPDYNAMICSDISPLAY Display a GP dynamics model.
% GPDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% GPDYNAMICSEXTRACTPARAM Extract parameters from the GP dynamics model.
% GPDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% GPDYNAMICSLOGLIKEGRADIENTS Gradients of the GP dynamics wrt parameters.
% GPDYNAMICSLOGLIKELIHOOD Give the log likelihood of GP dynamics.
% GPDYNAMICSPOINTLOGLIKELIHOOD Compute the log likelihood of a point under the GP dynamics model.
% GPDYNAMICSSAMP Sample from the dynamics for a given input.
% GPDYNAMICSSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM dynamics.
% GPDYNAMICSSEQUENCELOGLIKELIHOOD Return the log likelihood of a given latent sequence.
% GPDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPREVERSIBLEDYNAMICSCREATE Create the dynamics model. 
% GPREVERSIBLEDYNAMICSDISPLAY Display a GP dynamics model.
% GPREVERSIBLEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% GPREVERSIBLEDYNAMICSEXTRACTPARAM Extract parameters from the GP reversible dynamics model.
% GPREVERSIBLEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% GPREVERSIBLEDYNAMICSLOGLIKEGRADIENTS Gradients of the GP reversible dynamics wrt parameters.
% GPREVERSIBLEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the dynamics part.
% GPREVERSIBLEDYNAMICSOPTIONS Return default options for GP reversible dynamics model.
% GPREVERSIBLEDYNAMICSSAMP Sample from the dynamics for a given input.
% GPREVERSIBLEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM.
% GPTIMEDYNAMICSCREATE Create the time dynamics model. 
% GPTIMEDYNAMICSDISPLAY Display a GP time dynamics model.
% GPTIMEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP time dynamics.
% GPTIMEDYNAMICSEXTRACTPARAM Extract parameters from the GP time dynamics model.
% GPTIMEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the time dynamics model.
% GPTIMEDYNAMICSLOGLIKEGRADIENTS Gradients of the GP dynamics wrt parameters.
% GPTIMEDYNAMICSLOGLIKELIHOOD Give the log likelihood of GP time dynamics.
% GPTIMEDYNAMICSOUT Evaluate the output of GPTIMEDYNAMICS.
% GPTIMEDYNAMICSSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM time dynamics.
% GPTIMEDYNAMICSSEQUENCELOGLIKELIHOOD Return the log likelihood of a given latent sequence.
% GPTIMEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% MODELLATENTGRADIENTS Gradients of the latent variables for dynamics models in the GPLVM.
% MODELSETLATENTVALUES Set the latent variables for dynamics models in the GPLVM.
% ROBONEDYNAMICSCREATE Create the dynamics model. 
% ROBONEDYNAMICSDISPLAY Display the robot dynamics model. 
% ROBONEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.
% ROBONEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.
% ROBONEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% ROBONEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% ROBTHREEDYNAMICSCREATE Create the dynamics model. 
% ROBTHREEDYNAMICSDISPLAY Display the robot dynamics model. 
% ROBTHREEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% ROBTHREEDYNAMICSEXTRACTPARAM Extract parameters from the robot three dynamics model.
% ROBTHREEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% ROBTHREEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot three dynamics wrt parameters.
% ROBTHREEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot three dynamics part.
% ROBTHREEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% ROBTWODYNAMICSCREATE Create the dynamics model. 
% ROBTWODYNAMICSDISPLAY Display the robot dynamics model. 
% ROBTWODYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.
% ROBTWODYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.
% ROBTWODYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% ROBTWODYNAMICSSETLATENTVALUES Set the latent values inside the model.
