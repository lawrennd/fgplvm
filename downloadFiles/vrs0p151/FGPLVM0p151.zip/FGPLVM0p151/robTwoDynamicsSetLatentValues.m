function model = robTwoDynamicsSetLatentValues(model, X)

% ROBTWODYNAMICSSETLATENTVALUES Set the latent values inside the model.
%
%	Description:
%	model = robTwoDynamicsSetLatentValues(model, X)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	robTwoDynamicsSetLatentValues.m version 1.3


model = robOneDynamicsSetLatentValues(model, X);
