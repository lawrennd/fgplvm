function param = robThreeDynamicsExtractParam(model)

% ROBTHREEDYNAMICSEXTRACTPARAM Extract parameters from the robot three dynamics model.
%
%	Description:
%	param = robThreeDynamicsExtractParam(model)
%

%	Copyright (c) 2007 Neil D. Lawrence
% 	robThreeDynamicsExtractParam.m version 1.2


param = [];