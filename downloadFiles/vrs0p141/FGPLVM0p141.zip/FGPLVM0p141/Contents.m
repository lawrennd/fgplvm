% FGPLVM toolbox
% Version 0.141		Wednesday 25 Oct 2006 at 22:09
% Copyright (c) 2006 Neil D. Lawrence
% 
% FGPLVMCREATE Create a GPLVM model with inducing variables.
% GPUPDATEKERNELS Update the kernels that are needed.
% GPREVERSIBLEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the dynamics part.
% FGPLVMTEST Test the gradients of the gpCovGrads function and the fgplvm models.
% GPREVERSIBLEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% GPDYNAMICSSEQUENCELOGLIKELIHOOD Return the log likelihood of a given latent sequence.
% GPDYNAMICSLOGLIKELIHOOD Give the log likelihood of the dynamics part.
% FGPLVMOPTIONS Return default options for FGPLVM model.
% GPGRADIENT Gradient wrapper for a GP model.
% GPREVERSIBLEDYNAMICSCREATE Create the dynamics model. 
% FGPLVMLOADRESULT Load a previously saved result.
% GPLOGLIKELIHOOD Compute the log likelihood of a GP.
% DEMSPGP1D1 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D2 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D3 Do a simple 1-D regression after Snelson & Ghahramani's example.
% DEMSPGP1D4 Do a simple 1-D regression after Snelson & Ghahramani's example.
% ROBTHREEDYNAMICSDISPLAY Display the robot dynamics model. 
% FGPLVMCOVGRADSTEST Test the gradients of the covariance.
% GPREVERSIBLEDYNAMICSEXTRACTPARAM Extract parameters from the GP reversible dynamics model.
% GPREVERSIBLEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% FGPLVMLOGLIKEGRADIENTS Compute the gradients for the FGPLVM.
% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.
% GPOPTIMISE Optimise the inducing variable based kernel.
% ROBONEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% ROBTHREEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% GPDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% FGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% CMDSROADDATA This script uses classical MDS to visualise some road distance data.
% GPREVERSIBLEDYNAMICSLOGLIKEGRADIENTS Gradients of the GP reversible dynamics wrt parameters.
% GPPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.
% FGPLVMSEQUENCEOBJECTIVE Wrapper function for objective of a single sequence in latent space and the corresponding output sequence.
% GPOBJECTIVE Wrapper function for GP objective.
% DEMWALKSITJOGDYNAMICSLEARN Learn the stick man dynamics.
% FGPLVMGRADIENT GP-LVM gradient wrapper.
% ROBTHREEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot three dynamics part.
% GPDISPLAY Display a Gaussian process model.
% GPDATAINDICES Return indices of present data.
% FGPLVMOPTIMISESEQUENCE Optimise the postion of a latent sequence.
% GPSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM.
% FGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% GPCOVGRADSTEST Test the gradients of the covariance.
% ROBTWODYNAMICSCREATE Create the dynamics model. 
% FGPLVMDYNAMICSRUN Visualise the manifold.
% GPREVERSIBLEDYNAMICSOPTIONS Return default options for GP reversible dynamics model.
% FGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% DEMVOWELS1 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints.
% DEMVOWELS2 Model the vowels data with a 2-D FGPLVM using RBF kernel.
% DEMVOWELS3 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints, but without PCA initialisation.
% FGPLVMOPTIMISE Optimise the FGPLVM.
% FGPLVMDYNAMICSPLOT 2-D scatter plot of the latent points.
% GPCOMPUTEM Compute the matrix m given the model.
% FGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% GPBLOCKINDICES Return indices of given block.
% DEMOIL1 Oil data with fully independent training conditional.
% DEMOIL2 Oil data with fully independent training conditional, and MLP back constraints.
% DEMOIL3 Oil data with deterministic training conditional.
% DEMOIL4 Oil data with deterministic training conditional, and MLP back constraints.
% DEMOIL5 Oil data with partially independent training conditional.
% DEMOIL6 Oil data with partially independent training conditional, and MLP back constraints.
% ROBONEDYNAMICSDISPLAY Display the robot dynamics model. 
% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.
% FGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% ROBONEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% GPDYNAMICSLOGLIKEGRADIENTS Gradients of the GP dynamics wrt parameters.
% GPPOSTERIORGRADMEANVAR Gadient of the mean and variances of the posterior at points given by X.
% GPPOSTERIORGRADMEANCOVAR Gadient of the mean and variances of the posterior at points given by X.
% MODELSETLATENTVALUES Set the latent variables for dynamics models in the GPLVM.
% DEMROBOTWIRELESS1 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMROBOTWIRELESS2 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMROBOTWIRELESS3 Wireless Robot data from University of Washington with dynamics and no back constraints.
% DEMROBOTWIRELESS4 Wireless Robot data from University of Washington with dynamics and back constraints.
% FGPLVMOBJECTIVE Wrapper function for GP-LVM objective.
% FGPLVMDISPLAY Display an FGPLVM model.
% FGPLVMDYNAMICSFIELDPLOT 2-D field plot of the dynamics.
% DEMROBOTWIRELESSNAVIGATE Take some test data for the robot and navigate with it.
% GPPOSTERIORMEANCOVAR Mean and covariances of the posterior at points given by X.
% FGPLVMKERNDYNAMICSSAMPLE Sample a field from a given kernel.
% FGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% DEMSTICK1 Model the stick man using an RBF kernel.
% DEMSTICK2 Model the stick man using an RBF kernel and dynamics.
% DEMSTICK3 Model the stick man using an RBF kernel and RBF kernel based back constraints.
% DEMSTICK4 Model the stick man using an RBF kernel and 3-D latent space.
% FGPLVMSEQUENCELOGLIKELIHOOD Log-likelihood of a sequence for the GP-LVM.
% DEMBRENDAN1 Use the GP-LVM to model the Frey face data with back constraints.
% MODELLATENTGRADIENTS Gradients of the latent variables for dynamics models in the GPLVM.
% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
% GPSCALEBIASGRADIENT Compute the gradient of the scale and bias.
% GPEXTRACTPARAM Extract a parameter vector from a GP model.
% FGPLVMFIELDPLOT 2-D field plot of the dynamics.
% ROBTHREEDYNAMICSEXTRACTPARAM Extract parameters from the robot three dynamics model.
% GPDYNAMICSSAMP Sample from the dynamics for a given input.
% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
% ROBTWODYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% GPDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% DEMCMU35GPLVMRECONSTRUCT Reconstruct right leg of CMU 35.
% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.
% GPOUT Evaluate the output of an Gaussian process model.
% FGPLVMLOGLIKELIHOOD Log-likelihood for a GP-LVM.
% GPLOGLIKEGRADIENTS Compute the gradients for the parameters and X.
% GPDYNAMICSEXTRACTPARAM Extract parameters from the GP dynamics model.
% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPREVERSIBLEDYNAMICSSAMP Sample from the dynamics for a given input.
% ROBTWODYNAMICSDISPLAY Display the robot dynamics model. 
% FGPLVMVISUALISE Visualise the manifold.
% GPDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% DEMTWOCLUSTERS1
% FGPLVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% GPDYNAMICSSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM dyanmics.
% FGPLVMOPTIMISEPOINT Optimise the postion of a latent point.
% GPDYNAMICSDISPLAY Display a GP dynamics model.
% GPREVERSIBLEDYNAMICSDISPLAY Display a GP dynamics model.
% DEMROBOTTRACES1 Wireless Robot data from University of Washington, with tailored dynamics.
% FGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% DEMSPGP1DPLOT Plot results from 1-D sparse GP.
% ROBTWODYNAMICSSETLATENTVALUES Set the latent values inside the model.
% ROBONEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% DYNAMICSTEST Run some tests on the specified dynamics model.
% ROBTWODYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% ROBTHREEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot three dynamics wrt parameters.
% ROBTHREEDYNAMICSCREATE Create the dynamics model. 
% FGPLVMTESTMISSING Make sure missing data likelihood match full ones.
% GPOPTIONS Return default options for GP model.
% ROBTWODYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% ROBONEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% FGPLVMSEQUENCEGRADIENT Wrapper function for gradient of a latent sequence.
% GPEXPANDPARAM Expand a parameter vector into a GP model.
% FGPLVMREADFROMFILE Load a file produced by the c++ implementation.
% FGPLVMREADFROMFID Load from a FID produced by the C++ implementation.
% DEMVOWELSLLE Model the vowels data with a 2-D FGPLVM using RBF kernel.
% DEMVOWELSISOMAP Model the vowels data with a 2-D FGPLVM using RBF kernel.
% ROBTHREEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPCREATE Create a GP model with inducing varibles/pseudo-inputs.
% FGPLVMSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM.
% FGPLVMPRINTPLOT Print latent space for learnt model.
% ROBONEDYNAMICSCREATE Create the dynamics model. 
% FGPLVMDYNAMICSPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% GPPOSTERIORMEANCOVARTEST Test the gradients of the mean and covariance.
% GPCOMPUTEALPHA Update the vector `alpha' for computing posterior mean quickly.
% GPREVERSIBLEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPDYNAMICSCREATE Create the dynamics model. 
% FGPLVMCLASSVISUALISE Callback function for visualising data in 2-D.
% GPUPDATEAD Update the representations of A and D associated with the model.
% DEMCMU35GPLVM1 Learn a GPLVM on CMU 35 data set.
% ROBTHREEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
