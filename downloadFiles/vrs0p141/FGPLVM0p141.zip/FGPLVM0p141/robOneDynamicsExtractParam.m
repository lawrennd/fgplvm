function param = robOneDynamicsExtractParam(model)

% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.
%
%	Description:
%	param = robOneDynamicsExtractParam(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	robOneDynamicsExtractParam.m version 1.3


param = [];