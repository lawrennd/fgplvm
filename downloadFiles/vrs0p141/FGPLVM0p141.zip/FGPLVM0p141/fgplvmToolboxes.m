
% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
%
%	Description:
%	

%	Copyright (c) 2006 Neil D. Lawrence
% 	fgplvmToolboxes.m version 1.8

importLatest('netlab');
importLatest('mocap');
importLatest('ndlutil');
importLatest('prior');
importLatest('mltools');
importLatest('optimi');
importLatest('datasets');
importLatest('kern');
