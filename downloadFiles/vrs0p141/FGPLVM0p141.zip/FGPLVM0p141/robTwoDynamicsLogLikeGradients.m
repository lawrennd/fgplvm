function g = robTwoDynamicsLogLikeGradients(model)

% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.
%
%	Description:
%	g = robTwoDynamicsLogLikeGradients(model)
%

%	Copyright (c) 2006 Neil D. Lawrence
% 	robTwoDynamicsLogLikeGradients.m version 1.3


g = [];