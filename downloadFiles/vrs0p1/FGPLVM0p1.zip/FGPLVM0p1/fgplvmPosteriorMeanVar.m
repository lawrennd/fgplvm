function [mu, varsigma] = fgplvmPosteriorMeanVar(model, X);

% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
%
% [mu, varsigma] = fgplvmPosteriorMeanVar(model, X);
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmPosteriorMeanVar.m version 




varsigma = zeros(size(X, 1), model.d);
mu = zeros(size(X, 1), model.d);

% Compute kernel for new point.
KX = kernCompute(model.kern, model.X, X);
KX_ustar = kernCompute(model.kern, model.X_u, X);
invK_uu = pdinv(model.K_uu);


switch model.approx
 case 'fitc'
   Qstarstar = zeros(size(model.X, 1), 1);
   for i = 1:size(model.X, 1)
     Qstarstar(i) = model.K_uf(:, i)'*invK_uu*model.K_uf(:, i);
   end
   Lambda = kernDiagCompute(model.kern, model.X) - Qstarstar + ...
            model.sigma2;
   Lambdainv = diag(1./Lambda);
 otherwise
end
switch model.approx
 case 'ftc'
 case 'dtc'
  Sigma = pdinv(model.K_uu + 1/model.sigma2*(model.K_uf*model.K_uf'));
 case 'fitc'
  Sigma = pdinv(model.K_uu + (model.K_uf*Lambdainv*model.K_uf'));
end
%K_ufKX = model.K_uf*KX;

switch model.approx
 
 case 'ftc'
  % Compute kernel for new point.
  kX = kernCompute(model.kern, X, model.X)';
  
  % COmpute diagonal of kernel for new point.
  diagK = kernDiagCompute(model.kern, X);
  Kinv = pdinv(model.K_uu);
  Kinvk = Kinv*kX;
  for n = 1:size(X, 1)
    varsigma(n, :) = repmat(diagK(n) - kX(:, n)'*Kinvk(:, n), 1, model.d);
    if varsigma(n, 1) < 0
      warning('Varsigma less than zero');
    end
  end
  mu = Kinvk'*model.Y;

 case 'dtc'
  mu = KX_ustar'*Sigma*model.K_uf*model.Y/model.sigma2;
 case 'fitc'
  mu = KX_ustar'*Sigma*model.K_uf*Lambdainv*model.Y;
end

switch model.approx
 case 'ftc'
 case {'dtc', 'fitc', 'pitc'}
  for i = 1:size(X, 1)
    varsig = kernDiagCompute(model.kern, X(i, :))...
             -KX_ustar(:, i)'*(invK_uu-Sigma)*KX_ustar(:, i);
    if varsig < 0
      warning('Varsig less than zero');
    end
    varsigma(i, :) = repmat(varsig, 1, model.d);
  end
end

% Add the mean back in.
mu = mu.*repmat(model.scales, size(X, 1), 1) + repmat(model.m, size(X, 1), 1);
varsigma = varsigma.*repmat(model.scales.*model.scales, size(X, 1), ...
                            1);