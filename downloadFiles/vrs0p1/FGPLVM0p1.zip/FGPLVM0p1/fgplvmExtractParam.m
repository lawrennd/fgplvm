function params = fgplvmExtractParam(model)

% FGPLVMEXTRACTPARAM Extract a parameter vector from a GPLVM EZFT model.
%
% params = fgplvmExtractParam(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmExtractParam.m version 




switch model.approx
 case 'ftc'
  params =  kernExtractParam(model.kern);
 case {'dtc', 'fitc', 'pitc'}
  fhandle = str2func([model.sigma2Transform 'Transform']);
  params =  [kernExtractParam(model.kern) fhandle(model.sigma2, ...
                                                  'xtoa') model.X_u(:)'];
end
if isfield(model, 'back')
  params = [modelExtractParam(model.back) params];
else
  params = [model.X(:)' params];
end

