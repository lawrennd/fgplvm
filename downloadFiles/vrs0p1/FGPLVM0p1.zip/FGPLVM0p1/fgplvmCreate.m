function model = fgplvmCreate(Y, latentDim, approx, numActive, kern, ...
                                 prior, backModel, varargin)

% FGPLVMCREATE Create a GPLVM model with inducing varibles.
%
% model = fgplvmCreate(Y, latentDim, approx, numActive, kern, ...
%                                 prior, backModel, varargin)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmCreate.m version 



model.m = mean(Y, 1);
model.scales = ones(1, size(Y, 2));;
Y = Y - repmat(model.m, size(Y, 1), 1);
Y = Y./repmat(model.scales, size(Y, 1), 1);
model.q = latentDim;
model.d = size(Y, 2);
model.N = size(Y, 1);
% Initialise X with PCA.
model.Y = Y;
model.X = ppcaEmbed(Y, latentDim);


model.type = 'fgplvm';

  model.approx = approx;
switch approx
 case 'ftc'
  model.k = 0;
  model.X_u = [];
 case {'dtc', 'fitc', 'pitc'}
  % Sub-sample inducing variables.
  model.k = numActive;
  ind = randperm(model.N);
  ind = ind(1:model.k);
  model.X_u = model.X(ind, :);

  
end
model.sigma2 = exp(-2);
model.sigma2Transform = 'negLogLogit';
if isstruct(kern) 
  model.kern = kern;
else
  model.kern = kernCreate(model.X, kern);
end


if nargin < 6
  model.prior = priorCreate('gaussian');
elseif isstruct(prior)
  model.prior = prior;
else
  model.prior = priorCreate(prior);
  if nargin >6
    if isstruct(backModel)
      model.back = backModel;
    else
      fhandle = str2func([backModel 'Create']);
      model.back = fhandle(model.d, model.q, varargin{:});
    end
    model.back = mappingOptimise(model.back, model.Y, model.X);
  end
end
  
initParams = fgplvmExtractParam(model);
% This forces kernel computation.
model = fgplvmExpandParam(model, initParams);

