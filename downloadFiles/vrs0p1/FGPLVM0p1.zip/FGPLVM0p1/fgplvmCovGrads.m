function [gK_uu, gK_uf, g_Lambda] = fgplvmCovGrads(model)

% FGPLVMCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
%
% [gK_uu, gK_uf, g_Lambda] = fgplvmCovGrads(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmCovGrads.m version 



invK_uu = pdinv(model.K_uu);
switch model.approx
 case 'dtc'
  % Deterministic training condtional.
  K_uf2 = model.K_uf*model.K_uf';
  A = model.sigma2*model.K_uu+ K_uf2;
  Ainv = pdinv(A);
  E = model.K_uf*model.Y;
  EET = E*E';
  AinvEET = Ainv*EET;
  AinvEETAinv = AinvEET*Ainv;
  gK_uu = 0.5*model.d*invK_uu...
          - 0.5*model.d*model.sigma2*Ainv ...
          - 0.5*AinvEETAinv;
  %  gK_uu = 0.5*model.d*invK_uu;
  
  AinvK_uf = Ainv*model.K_uf;
  gK_uf = -model.d*AinvK_uf-1/model.sigma2*Ainv*EET*AinvK_uf+1/model.sigma2*(Ainv*E*model.Y');
  % gK_uf = zeros(size(model.K_uf));
  
  g_Lambda = -model.d*(model.N-model.k)/(2*model.sigma2) ...
      -0.5*model.d*sum(sum(Ainv.*model.K_uu)) ...
      -0.5*sum(sum(AinvEETAinv.*model.K_uu))/model.sigma2 ...
      -0.5*trace(AinvEET)/(model.sigma2*model.sigma2) ...
      + 0.5/(model.sigma2*model.sigma2)*sum(sum(model.Y.*model.Y));
  
  
  fhandle = str2func([model.sigma2Transform 'Transform']);
  g_Lambda = g_Lambda*fhandle(model.sigma2, 'gradfact');
  
 case 'fitc'
  % Fully independent training conditonal.
  
 case 'pitc' 
  % Partially independent training conditional.
  
 otherwise
  error('Unknown approximation type');
end