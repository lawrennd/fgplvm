% FGPLVM toolbox
% Version 0.1		Wednesday 30 Nov 2005 at 01:30
% Copyright (c) 2005 Neil D. Lawrence
% 
% DEMOIL1 Model the oil data with a 2-D FGPLVM using RBF kernel.
% DEMOIL100 Model the sub-sampled oil data with a 2-D FGPLVM using RBF kernel.
% DEMOIL1 Model the oil data with a 2-D FGPLVM using RBF kernel.
% DEMSTICK1 Model the stick man using an RBF kernel.
% DEMSTICK2 Model the stick man using an RBF kernel and dynamics.
% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
% FGPLVMCLASSVISUALISE Callback function for visualising data in 2-D.
% FGPLVMCOVGRADS Sparse objective function gradients wrt Covariance functions for inducing variables.
% FGPLVMCREATE Create a GPLVM model with inducing varibles.
% FGPLVMDYNAMICSFIELDPLOT 2-D field plot of the dynamics.
% FGPLVMDYNAMICSLOGLIKEGRADIENTS Gradients of the dynamics portion.
% FGPLVMDYNAMICSLOGLIKELIHOOD Gradients of the dynamics portion of the log likelihood..
% FGPLVMDYNAMICSPLOT 2-D scatter plot of the latent points.
% FGPLVMDYNAMICSPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMDYNAMICSRUN Visualise the manifold.
% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
% FGPLVMEXPANDPARAM Expand a parameter vector into a GPLVM EZFT model.
% FGPLVMEXTRACTPARAM Extract a parameter vector from a GPLVM EZFT model.
% FGPLVMFIELDPLOT 2-D field plot of the dynamics.
% FGPLVMGRADIENT GPLVM gradient wrapper for the log likelihood in the EZFT approach.
% FGPLVMLOADRESULT Load a previously saved result.
% FGPLVMLOGLIKEGRADIENTS Compute the gradients of the EZFT sparse covariance.
% FGPLVMLOGLIKELIHOOD Log-likelihood for the EZFT approach.
% FGPLVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% FGPLVMOBJECTIVE Wrapper function for EZFT objective.
% FGPLVMOPTIMISE Optimise the inducing variable based kernel.
% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMREADFROMFID Load from a FID produced by the C++ implementation.
% FGPLVMREADFROMFILE Load a file produced by the c++ implementation.
% FGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% FGPLVMVISUALISE Visualise the manifold.
