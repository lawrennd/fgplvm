function f = fgplvmObjective(params, model)

% FGPLVMOBJECTIVE Wrapper function for EZFT objective.
%
% f = fgplvmObjective(params, model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmObjective.m version 



model = fgplvmExpandParam(model, params);
f = - fgplvmLogLikelihood(model);
