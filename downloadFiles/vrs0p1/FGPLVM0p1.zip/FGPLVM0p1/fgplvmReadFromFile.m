function [model,labels] = fgplvmReadFromFile(fileName)

% FGPLVMREADFROMFILE Load a file produced by the c++ implementation.
%
% [model,labels] = fgplvmReadFromFile(fileName)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmReadFromFile.m version 



FID = fopen(fileName);
if FID==-1
  error(['Cannot find file ' fileName])
end
[model, labels] = fgplvmReadFromFID(FID);
fclose(FID);