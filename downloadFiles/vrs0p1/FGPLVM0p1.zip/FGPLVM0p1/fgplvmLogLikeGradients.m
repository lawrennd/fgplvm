function g = fgplvmLogLikeGradients(model)

% FGPLVMLOGLIKEGRADIENTS Compute the gradients of the EZFT sparse covariance.
%
% g = fgplvmLogLikeGradients(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmLogLikeGradients.m version 



switch model.approx
 case 'ftc'
  
  gKX = kernGradX(model.kern, model.X, model.X);
  gKX = gKX*2;
  dgKX = kernDiagGradX(model.kern, model.X);
  for i = 1:model.N
    gKX(i, :, i) = dgKX(i, :);
  end
  gParam = zeros(1, model.kern.nParams);
  gX = zeros(model.N, model.q);
  for k = 1:model.d
    gK = fgplvmCovarianceGradients(model, k);
    for i = 1:model.N
      for j = 1:model.q
       gX(i, j) = gX(i, j) + gKX(:, j, i)'*gK(:, i);
      end
    end
    gParam = gParam + kernGradient(model.kern, model.X, gK);
  end
  
  
 case 'dtc'
  [gK_u, gK_uf, g_Lambda] = fgplvmCovGrads(model);
  gKX = kernGradX(model.kern, model.X_u, model.X_u);
  
  % The 2 accounts for the fact that covGrad is symmetric
  gKX = gKX*2;
  dgKX = kernDiagGradX(model.kern, model.X_u);
  for i = 1:model.k
    gKX(i, :, i) = dgKX(i, :);
  end
  for i = 1:model.k
    for j = 1:model.q
      g_I(i, j) = gKX(:, j, i)'*gK_u(:, i);
    end
  end
  gKX_uf = kernGradX(model.kern, model.X_u, model.X);
  for i = 1:model.k
    for j = 1:model.q
      g_I(i, j) = g_I(i, j) + gKX_uf(:, j, i)'*gK_uf(i, :)';
    end
  end
  
  % TODO this and the previous kernGradX should probably be combined.
  % this needs to be recomputed so that it is wrt model.X not model.X_u
  gKX_uf = kernGradX(model.kern, model.X, model.X_u);
  for i = 1:model.N
    for j = 1:model.q
      gX(i, j) = gKX_uf(:, j, i)'*gK_uf(:, i);
    end
  end
  
  gParam_I = kernGradient(model.kern, model.X_u, gK_u);
  gParam_Istar = kernGradient(model.kern, model.X_u, model.X, gK_uf);
  g_param = gParam_I + gParam_Istar;
  
  gParam = [g_I(:)' g_param(:)' g_Lambda];
 
 case 'fitc'
 case 'pitc'
  
 otherwise
  error('Unrecognised model approximation');
end

if isfield(model, 'dynamics') & ~isempty(model.dynamics)
  % Dynamics kernel is being used.
  gX = gX + fgplvmDynamicsLogLikeGradients(model);
  if isfield(model, 'prior') &  ~isempty(model.prior)
    gX(1, :) = gX(1, :) + priorGradient(model.prior, model.X(1, :)); 
  end
elseif isfield(model, 'prior') &  ~isempty(model.prior)
  gX = gX + priorGradient(model.prior, model.X); 
end


% Check for back constraints.
if isfield(model, 'back')
  g_w = modelOutputGrad(model.back, model.Y);
  g_modelParams = zeros(size(g_w, 2), 1);
  for i = 1:model.q
    g_modelParams = g_modelParams + g_w(:, :, i)'*gX(:, i);
  end
  g = [g_modelParams(:)' gParam];
else
  g = [gX(:)' gParam];
end


function gK = fgplvmCovarianceGradients(model, dimension)

% FGPLVMCOVARIANCEGRADIENTS


invKy = model.invK_uu*model.Y(:, dimension);
gK = -model.invK_uu + invKy*invKy';
gK = gK*.5;

