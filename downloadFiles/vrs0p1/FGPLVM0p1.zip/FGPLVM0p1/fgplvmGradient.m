function g = fgplvmGradient(params, model)

% FGPLVMGRADIENT GPLVM gradient wrapper for the log likelihood in the EZFT approach.
%
% g = fgplvmGradient(params, model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmGradient.m version 



model = fgplvmExpandParam(model, params);
g = - fgplvmLogLikeGradients(model);
