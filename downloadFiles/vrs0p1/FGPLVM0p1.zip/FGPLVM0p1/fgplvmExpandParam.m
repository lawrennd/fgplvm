function model = fgplvmExpandParam(model, params)

% FGPLVMEXPANDPARAM Expand a parameter vector into a GPLVM EZFT model.
%
% model = fgplvmExpandParam(model, params)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmExpandParam.m version 



startVal = 1;
if isfield(model, 'back')
  endVal = model.back.numParams;
  model.back = modelExpandParam(model.back, params(startVal:endVal));
  model.X = modelOut(model.back, model.Y);
else
  endVal = model.N*model.q;
  model.X = reshape(params(startVal:endVal), model.N, model.q);
end
startVal = endVal+1;
endVal = endVal + model.k*model.q;
model.X_u = reshape(params(startVal:endVal), model.k, model.q);
startVal = endVal +1;
endVal = endVal + model.kern.nParams;
model.kern = kernExpandParam(model.kern, params(startVal:endVal));


switch model.approx
  case 'ftc'
   model.K_uu = kernCompute(model.kern, model.X);
   model.invK_uu = pdinv(model.K_uu);
 case {'dtc', 'fitc', 'pitc'}
  model.K_uu = kernCompute(model.kern, model.X_u);
  model.K_uf = kernCompute(model.kern, model.X_u, model.X);
  fhandle = str2func([model.sigma2Transform 'Transform']);
  model.sigma2 = fhandle(params(end), 'atox');
end

% If there is no white portion on the kernel
if model.kern.whiteVariance == 0
  % add jitter.
  for i = 1:size(model.K_uu, 1)
    model.K_uu(i, i) = model.K_uu(i, i) + 1e-6;
  end
end


if isfield(model, 'dynamics') & ~isempty(model.dynamics)
  model.dynamics.K = kernCompute(model.dynamics.kern, model.X(1:end-1, ...
                                                    :));
  [model.dynamics.invK, U] = pdinv(model.dynamics.K);
  [model.dynamics.logdetK] = logdet(model.dynamics.K, U);
end
  