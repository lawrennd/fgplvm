function model = fgplvmAddDynamics(model, kernType, snRatio)

% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
%
% model = fgplvmAddDynamics(model, kernType, snRatio)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmAddDynamics.m version 


% Set up dynamics kernel.
if nargin< 3 
  snRatio = 100;
end
if isstruct(kernType)
  model.dynamics.kern = kernType;
else
  model.dynamics.kern = kernCreate(model.X(1:end-1, :), kernType);
  signalSize = kernGetVariance(model.dynamics.kern);
  
  model.dynamics.kern = kernSetWhite(model.dynamics.kern, signalSize/(snRatio*snRatio));
end
params = fgplvmExtractParam(model);
model = fgplvmExpandParam(model, params);
