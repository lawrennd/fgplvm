function ll = fgplvmLogLikelihood(model)

% FGPLVMLOGLIKELIHOOD Log-likelihood for the EZFT approach.
%
% ll = fgplvmLogLikelihood(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmLogLikelihood.m version 



switch model.approx
 case 'ftc'
  % No approximation, just do a full computation on K.
  [invK_uu, U] = pdinv(model.K_uu);
  logDetK = logdet(model.K_uu, U);
  ll = 0;
  for i = 1:size(model.m, 2)
    ll = ll -.5*logDetK- .5*model.Y(:, i)'*invK_uu*model.Y(:, i);
  end
 case 'dtc'
   % Deterministic training conditional
   K_uf2 = model.K_uf*model.K_uf';
   A = model.sigma2*model.K_uu+ K_uf2;
   [Ainv, U] = pdinv(A);
   logdetA = logdet(A, U);
   E = model.K_uf*model.Y;
   EET = E*E';
   ll =  -0.5*model.d*(model.N-model.k)*log(model.sigma2) + 0.5*model.d*logdet(model.K_uu) ...
         -0.5*model.d*logdetA + 0.5*sum(sum(Ainv.*EET))/model.sigma2 ...
         -0.5*sum(sum(model.Y.*model.Y))/model.sigma2;
 case 'fitc'
  % Fully independent training conditional. Ed and Zoubin's likelihood.
  invK_uu = pdinv(model.K_uu);
  Q_ff = model.K_uf'*invK_uu*model.K_uf;
  Lambda = diag(model.diagK - diag(Q_ff));  
  C = Q_ff-Lambda;
  ll = -0.5*model.d*logdet(C) ...
       -0.5*trace(C*model.Y*model.Y');
 case 'pitc'
  % Partially independent training conditional.
end

if isfield(model, 'dynamics') & ~isempty(model.dynamics)
  % Dynamics kernel is being used.
  ll = ll + fgplvmDynamicsLogLikelihood(model);
  if isfield(model, 'prior') &  ~isempty(model.prior)
    ll = ll + priorLogProb(model.prior, model.X(1, :));
  end
  
elseif isfield(model, 'prior') &  ~isempty(model.prior)
  for i = 1:model.N
    ll = ll + priorLogProb(model.prior, model.X(i, :));
  end
end
