% DEMSTICK1 Model the stick man using an RBF kernel.
%
% 

% Copyright (c) 2005 Neil D. Lawrence
% demStick1.m version 



% Fix seeds
randn('seed', 1e5);
rand('seed', 1e5);

dataSetName = 'run1'
experimentNo = 1;

% load data
[Y, connect] = mocapLoadTextData(dataSetName);
Y = Y(1:4:end, :);

% Set up model
numActive = 100;
latentDim = 2;
model = fgplvmCreate(Y, latentDim, 'ftc', numActive, {'rbf', 'bias', 'white'}, 'gaussian');

% Optimise the model.
iters = 500;
display = 1;

model = fgplvmOptimise(model, display, iters);

% Save the results.
capName = dataSetName;;
capName(1) = upper(capName(1));
save(['dem' capName num2str(experimentNo) '.mat'], 'model');

% Load the results and display dynamically.
fgplvmResultsDynamic(dataSetName, experimentNo, 'stick', connect)

