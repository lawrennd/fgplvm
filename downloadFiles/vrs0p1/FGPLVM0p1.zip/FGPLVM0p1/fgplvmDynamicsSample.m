function [ax, data] = fgplvmDynamicsSample(model, points);

% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
%
% [ax, data] = fgplvmDynamicsSample(model, points);
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmDynamicsSample.m version 



% Dynamics are only currently visible in two-d.

if nargin < 2
  points = 20;
end
if(size(model.X, 2)~=2)
  error(['Latent space should be two-dimensional to sample ' ...
         'dynamics'])
end

x1 = linspace(min(model.X(:, 1))*1.1, max(model.X(:, 1))*1.1, points);
x2 = linspace(min(model.X(:, 2))*1.1, max(model.X(:, 2))*1.1, points);
[X1, X2] = meshgrid(x1, x2);

XTest = [X1(:), X2(:)];
K = kernCompute(model.dynamics.kern, XTest);
Y = gsamp(zeros(1, size(XTest, 1)), K, 2)';
Y = Y -XTest;
Y1 = reshape(Y(:, 1), size(X1));
Y2 = reshape(Y(:, 2), size(X2));
handle = quiver(X1, X2, Y1, Y2);
set(handle, 'linewidth', 2);
colormap gray;
xLim = [min(XTest(:, 1)) max(XTest(:, 1))];
yLim = [min(XTest(:, 2)) max(XTest(:, 2))];
set(gca, 'xLim', xLim);
set(gca, 'yLim', yLim);

set(gca, 'fontname', 'arial');
set(gca, 'fontsize', 20);
