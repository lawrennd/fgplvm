function ll = fgplvmDynamicsLogLikelihood(model)

% FGPLVMDYNAMICSLOGLIKELIHOOD Gradients of the dynamics portion of the log likelihood..
%
% ll = fgplvmDynamicsLogLikelihood(model)
%

% Copyright (c) 2005 Neil D. Lawrence
% fgplvmDynamicsLogLikelihood.m version 



ll = 0;
switch model.approx
 case {'ftc', 'dtc', 'fitc', 'pitc'}
  % For the moment do them all together.
  for i = 1:model.q
    ll = ll + model.dynamics.logdetK ...
         + model.X(2:end, i)'*model.dynamics.invK*model.X(2:end, i);
  end
end
ll = ll*-0.5;
  