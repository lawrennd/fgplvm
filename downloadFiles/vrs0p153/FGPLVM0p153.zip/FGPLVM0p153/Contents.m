% FGPLVM toolbox
% Version 0.153		11-Oct-2008
% Copyright (c) 2008, Neil D. Lawrence
% 
, Neil D. Lawrence
% DEMVOWELS2 Model the vowels data with a 2-D FGPLVM using RBF kernel.
% FGPLVMSEQUENCEGRADIENT Wrapper function for gradient of a latent sequence.
% MODELLATENTGRADIENTS Gradients of the latent variables for dynamics models in the GPLVM.
% FGPLVMGRADIENT GP-LVM gradient wrapper.
% FGPLVMLOADRESULT Load a previously saved result.
% GPDYNAMICSSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM dynamics.
% FGPLVMREADFROMFID Load from a FID produced by the C++ implementation.
% FGPLVMPOINTSAMPLELOGLIKELIHOOD
% GPREVERSIBLEDYNAMICSOPTIONS Return default options for GP reversible dynamics model.
% GPDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% DEMCMU35GPLVM3 Learn a GPLVM on CMU 35 data set.
% GPREVERSIBLEDYNAMICSCREATE Create the dynamics model. 
% DEMSTICKFGPLVM1 Model the stick man using an RBF kernel.
% GPDYNAMICSLOGLIKEGRADIENTS Gradients of the GP dynamics wrt parameters.
% ROBONEDYNAMICSCREATE Create the dynamics model. 
% FGPLVMOPTIMISEPOINT Optimise the postion of a latent point.
% DEMFOURWALKS1 Model four seperate walsk using an RBF kernel and dynamics.
% FGPLVMNEARESTNEIGHBOUR Give the number of errors in latent space for 1 nearest neighbour.
% FGPLVMADDDYNAMICS Add a dynamics kernel to the model.
% GPTIMEDYNAMICSDISPLAY Display a GP time dynamics model.
% CMDSROADDATA This script uses classical MDS to visualise some road distance data.
% ROBTHREEDYNAMICSEXTRACTPARAM Extract parameters from the robot three dynamics model.
% FGPLVMEXTRACTPARAM Extract a parameter vector from a GP-LVM model.
% DEMCMU35GPLVM4 Learn a GPLVM on CMU 35 data set.
% FGPLVMDISPLAY Display an FGPLVM model.
% DEMROBOTWIRELESS3 Wireless Robot data from University of Washington with dynamics and no back constraints.
% FGPLVMCREATE Create a GPLVM model with inducing variables.
% FGPLVMVISUALISE Visualise the manifold.
% DEMCMU35SEQUENCEOPTIMISE 
% FGPLVMOPTIMISE Optimise the FGPLVM.
% DEMOIL4 Oil data with deterministic training conditional, and MLP back constraints.
% ROBONEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% DEMCMU35GPLVMRECONSTRUCT Reconstruct right leg and body of CMU 35.
% GPLVMCMU35ANIMATE Animate the test data jointly with predictions.
% ROBTWODYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% FGPLVMDYNAMICSRUN Runs auto regressive dynamics in a forward manner.
% GPREVERSIBLEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% GPDYNAMICSDISPLAY Display a GP dynamics model.
% GPDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% FGPLVMREADFROMFILE Load a file produced by the C++ implementation.
% DEMSTICK4 Model the stick man using an RBF kernel and 3-D latent space.
% GPDYNAMICSLOGLIKELIHOOD Give the log likelihood of GP dynamics.
% FGPLVMPOINTGRADIENT Wrapper function for gradient of a single point.
% GPTIMEDYNAMICSCREATE Create the time dynamics model. 
% DEMCMU35GPLVM1 Learn a GPLVM on CMU 35 data set.
% FGPLVMTESTMISSING Make sure missing data likelihood match full ones.
% FGPLVMOBJECTIVE Wrapper function for GP-LVM objective.
% DEMOIL3 Oil data with deterministic training conditional.
% FGPLVMPOINTOBJECTIVE Wrapper function for objective of a single point in latent space and the output location..
% FGPLVMFIELDPLOT 2-D field plot of the dynamics.
% DEMOIL1 Oil data with fully independent training conditional.
% ROBTWODYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot one dynamics part.
% FGPLVMPOINTLOGLIKEGRADIENT Log-likelihood gradient for of a point of the GP-LVM.
% ROBTWODYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% FGPLVMSEQUENCEOBJECTIVE Wrapper function for objective of a single sequence in latent space and the corresponding output sequence.
% ROBTHREEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the robot three dynamics part.
% FGPLVMCOVGRADSTEST Test the gradients of the covariance.
% FGPLVMDYNAMICSPLOT 2-D scatter plot of the latent points.
% GPTIMEDYNAMICSOUT Evaluate the output of GPTIMEDYNAMICS.
% DEMWALKSITJOGDYNAMICSLEARN Learn the stick man dynamics.
% GPTIMEDYNAMICSLOGLIKELIHOOD Give the log likelihood of GP time dynamics.
% ROBONEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot one dynamics wrt parameters.
% ROBONEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% FGPLVMDYNAMICSPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMOBJECTIVEGRADIENT Wrapper function for FGPLVM objective and gradient.
% FGPLVMSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM.
% DEMTWOCLUSTERS1
% FGPLVMPOINTLOGLIKELIHOOD Log-likelihood of a point for the GP-LVM.
% GPREVERSIBLEDYNAMICSLOGLIKELIHOOD Give the log likelihood of the dynamics part.
% DYNAMICSTEST Run some tests on the specified dynamics model.
% DEMVOWELSISOMAP Model the vowels data with a 2-D FGPLVM using RBF kernel.
% MODELSETLATENTVALUES Set the latent variables for dynamics models in the GPLVM.
% FGPLVMCLASSVISUALISE Callback function for visualising data in 2-D.
% DEMFOURWALKSRECONSTRUCT Reconstruct right leg of CMU 35.
% GPTIMEDYNAMICSLOGLIKEGRADIENTS Gradients of the GP dynamics wrt parameters.
% DEMCMU35GPLVM2 Learn a GPLVM on CMU 35 data set.
% GPDYNAMICSCREATE Create the dynamics model. 
% FGPLVMOPTIMISESEQUENCE Optimise the postion of a latent sequence.
% FGPLVMTAYLORANGLEERRORS Helper function for computing angle errors for CMU 35 data.
% DEMCMU35ANIMATE Animate reconstructed right leg and body.
% DEMOIL2 Oil data with fully independent training conditional, and MLP back constraints.
% DEMSTICK3 Model the stick man using an RBF kernel and RBF kernel based back constraints.
% ROBONEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% DEMCMU35TAYLORNEARESTNEIGHBOUR Recreate the Nearest Neighbour result from Taylor et al, NIPS 2006.
% GPDYNAMICSPOINTLOGLIKELIHOOD Compute the log likelihood of a point under the GP dynamics model.
% FGPLVMPRINTPLOT Print latent space for learnt model.
% DEMSTICK2 Model the stick man using an RBF kernel and dynamics.
% GPREVERSIBLEDYNAMICSEXTRACTPARAM Extract parameters from the GP reversible dynamics model.
% GPSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM.
% DEMROBOTWIRELESS2 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% DEMVOWELS1 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints.
% GPTIMEDYNAMICSEXTRACTPARAM Extract parameters from the GP time dynamics model.
% FGPLVMRESULTSDYNAMIC Load a results file and visualise them.
% FGPLVMBACKCONSTRAINTGRAD Gradient with respect to back constraints if present.
% GPTIMEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% FGPLVMSEQUENCEOBJECTIVEGRADIENT Wrapper function for objective
% FGPLVMKERNDYNAMICSSAMPLE Sample a field from a given kernel.
% GPREVERSIBLEDYNAMICSSAMP Sample from the dynamics for a given input.
% DEMCMU35GPLVMRECONSTRUCTTAYLOR Reconstruct right leg of CMU 35.
% ROBONEDYNAMICSEXTRACTPARAM Extract parameters from the robot one dynamics model.
% DEMOIL6 Oil data with partially independent training conditional, and MLP back constraints.
% GPDYNAMICSSAMP Sample from the dynamics for a given input.
% FGPLVMEXPANDPARAM Expand a parameter vector into a GP-LVM model.
% FGPLVMDYNAMICSSAMPLE Sample a field from the GP.
% ROBTWODYNAMICSLOGLIKEGRADIENTS Gradients of the robot two dynamics wrt parameters.
% GPREVERSIBLEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPTIMEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the time dynamics model.
% FGPLVMCMU35ANIMATE Animate the test data jointly with predictions.
% ROBTHREEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% FGPLVMSEQUENCELOGLIKELIHOOD Log-likelihood of a sequence for the GP-LVM.
% ROBTWODYNAMICSDISPLAY Display the robot dynamics model. 
% FGPLVMLOGLIKEGRADIENTS Compute the gradients for the FGPLVM.
% DEMVOWELSLLE Model the vowels data with a 2-D FGPLVM using RBF kernel.
% ROBTHREEDYNAMICSSETLATENTVALUES Set the latent values inside the model.
% GPREVERSIBLEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% DEMROBOTWIRELESS1 Wireless Robot data from University of Washington, without dynamics and without back constraints.
% FGPLVMPOSTERIORMEANVAR Mean and variances of the posterior at points given by X.
% FGPLVMPOINTOBJECTIVEGRADIENT Wrapper function for objective and gradient of a single point in latent space and the output location..
% DEMROBOTTRACES1 Wireless Robot data from University of Washington, with tailored dynamics.
% ROBTWODYNAMICSCREATE Create the dynamics model. 
% FGPLVMOPTIONS Return default options for FGPLVM model.
% FGPLVMTEST Test the gradients of the gpCovGrads function and the fgplvm models.
% DEMOIL5 Oil data with partially independent training conditional.
% ROBONEDYNAMICSDISPLAY Display the robot dynamics model. 
% GPREVERSIBLEDYNAMICSLOGLIKEGRADIENTS Gradients of the GP reversible dynamics wrt parameters.
% ROBTWODYNAMICSSETLATENTVALUES Set the latent values inside the model.
% DEMSTICK1 Model the stick man using an RBF kernel.
% FGPLVMDYNAMICSFIELDPLOT 2-D field plot of the dynamics.
% ROBTHREEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot three dynamics wrt parameters.
% FGPLVMLOGLIKELIHOOD Log-likelihood for a GP-LVM.
% DEMROBOTWIRELESSNAVIGATE Take some test data for the robot and navigate with it.
% ROBTHREEDYNAMICSEXPANDPARAM Place the parameters vector into the model for first robot dynamics.
% GPTIMEDYNAMICSSEQUENCELOGLIKEGRADIENT Log-likelihood gradient for of a sequence of the GP-LVM time dynamics.
% GPDYNAMICSSEQUENCELOGLIKELIHOOD Return the log likelihood of a given latent sequence.
% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
% ROBONEDYNAMICSLATENTGRADIENTS Gradients of the X vector given the dynamics model.
% DEMSTICK5 Model the stick man using an RBF kernel and regressive dynamics.
% DEMVOWELS3 Model the vowels data with a 2-D FGPLVM using RBF kernel and back constraints, but without PCA initialisation.
% ROBTWODYNAMICSEXTRACTPARAM Extract parameters from the robot two dynamics model.
% GPREVERSIBLEDYNAMICSDISPLAY Display a GP dynamics model.
% GPTIMEDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP time dynamics.
% GPDYNAMICSEXTRACTPARAM Extract parameters from the GP dynamics model.
% DEMROBOTWIRELESS4 Wireless Robot data from University of Washington with dynamics and back constraints.
% FGPLVMVITERBISEQUENCE Viterbi align a latent sequence.
% GPDYNAMICSEXPANDPARAM Place the parameters vector into the model for GP dynamics.
% ROBTHREEDYNAMICSCREATE Create the dynamics model. 
% GPTIMEDYNAMICSSEQUENCELOGLIKELIHOOD Return the log likelihood of a given latent sequence.
% ROBTHREEDYNAMICSDISPLAY Display the robot dynamics model. 
% DEMBRENDAN1 Use the GP-LVM to model the Frey face data with back constraints.
