
% FGPLVMTOOLBOXES Load in the relevant toolboxes for fgplvm.
%
%	Description:
%	% 	fgplvmToolboxes.m CVS version 1.12
% 	fgplvmToolboxes.m SVN version 102
% 	last update 2008-10-05T23:05:50.000000Z
importLatest('netlab');
importLatest('prior');
importLatest('optimi');
importLatest('datasets');
importLatest('mltools');
importLatest('kern');
importLatest('ndlutil');
importLatest('mocap');
importLatest('gp');