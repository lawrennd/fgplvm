function param = robThreeDynamicsExtractParam(model)

% ROBTHREEDYNAMICSEXTRACTPARAM Extract parameters from the robot three dynamics model.
%
%	Description:
%	param = robThreeDynamicsExtractParam(model)
%% 	robThreeDynamicsExtractParam.m CVS version 1.2
% 	robThreeDynamicsExtractParam.m SVN version 29
% 	last update 2007-11-03T14:33:38.000000Z

param = [];