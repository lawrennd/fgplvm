function model = gpReversibleDynamicsCreate(q, d, latentVals, options)

% GPREVERSIBLEDYNAMICSCREATE Create the dynamics model.
%
%	Description:
%	model = gpReversibleDynamicsCreate(q, d, latentVals, options)
%% 	gpReversibleDynamicsCreate.m CVS version 1.3
% 	gpReversibleDynamicsCreate.m SVN version 29
% 	last update 2007-11-03T14:32:44.000000Z

if nargin < 4
  options = gpReversibleDynamicsOptions('ftc');
end

diffs = latentVals(2:end, :) - latentVals(1:end-1, :);
X = [latentVals(2:end-1, :) diffs(1:end-1, :)];
y = diffs(2:end, :);
model = gpCreate(2*q, d, X, y, options);
model.learn = 0;
model.type = 'gpReversibleDynamics';

