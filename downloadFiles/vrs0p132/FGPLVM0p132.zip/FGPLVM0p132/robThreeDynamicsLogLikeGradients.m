function g = robThreeDynamicsLogLikeGradients(model)

% ROBTHREEDYNAMICSLOGLIKEGRADIENTS Gradients of the robot three dynamics wrt parameters.
%
% g = robThreeDynamicsLogLikeGradients(model)
%

% Copyright (c) 2006 Neil D. Lawrence
% robThreeDynamicsLogLikeGradients.m version 



g = [];